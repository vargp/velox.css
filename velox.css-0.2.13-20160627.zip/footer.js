
/*

Serrin footer.js v1.0.0
Requires:
- velox.css (minimum version 0.2.12).
- footer-instagram.png

Usage:
<div id="srn-footer" class="vlx-container"></div>
<script src="footer.js"></script>
<script>srn_footer();</script>

*/

function srn_footer()
{
	document.getElementById("srn-footer").innerHTML = 
		'<div class="vlx-l1-col1 vlx-black vlx-center vlx-padding-10 vlx-font-s">'
			+'<p>'
				+'Follow me on <a href="https://www.instagram.com/serrinsalamander/" target="_blank" title="instagram" class="vlx-color-white vlx-eff-img-grey-hover-rev vlx-eff-ease-hover"><img src="footer-instagram.png" class="vlx-circle" style="width: 20px; height: 20px;">/serrinsalamander</a>'
				+'&nbsp;&bull;&nbsp;'
				+'<a href="http://serrin.pe.hu" target="_blank" class="vlx-color-white">My apps</a>'
				+'&nbsp;&bull;&nbsp;'
				+'<a href="https://github.com/Serrin/velox.css" target="_blank" class="vlx-color-white">velox.css</a>'
			+'</p>'
			+'<p>&copy; Copyright '+new Date().getFullYear()+' Ferenc Czigler. All rights reserved.</p></p>'
		+'</div>';
}
